# 未标定一维分层燃料电池冷启动模型

这是一份可直接在 VS Code 中打开的 Python 项目。默认运行未标定模型，不附带此前 −20 ℃拟合参数，也不会寻找或自动读取旧的 fit.json。参数校正由你主动运行 `calibrate.py` 完成，结果写到独立输出目录，基准参数文件保持不变。

请先按本文走完“运行未标定模型”，再进入“亲手进行参数标定”。代码用英文变量名和英文图例，教程与参数说明用中文，避免不同电脑中文字体缺失导致图像无法显示。

## 一 先理解这份模型

空间结构为 aGDL → aCL → PEM → cCL → cGDL，热域另外包含两侧双极板。模型不含辅助加热源，不使用恒定膜含水量：孔隙水蒸气、液水、冰，以及离聚物未冻结水、等效冻结水分别进行质量记账。

默认求解 H₂/O₂ 的瞬态储存与扩散，恢复原建模稿的反应气体守恒形式；此前用于快速标定的准稳态气体近似仍可通过 `--gas-mode quasisteady` 显式选择。标定、运行和验证必须使用同一种选项。其余模型假设与实现边界见 [模型实现说明](docs/MODEL.md)，完整推导见 [模型方程](docs/模型方程.md)。

**“未标定”不等于“所有参数都已确定”。**题目没有确定的相变速率、膜水冻结宽度等采用有来源标记的假设初值。具体取值见 [参数说明](docs/PARAMETERS.md)，后续需要材料数据或实验辨识。任何运行结果都不能跳过物理和误差检查直接作为可靠预测。

## 二 需要哪些文件和软件

本项目已带齐模型运行需要的文件：

| 文件 | 用途 | 是否需要你另找 |
|---|---|---|
| `model.py` | 一维分层控制方程及 BDF 求解器 | 否 |
| `configs/baseline.json` | 未标定基准参数 | 否 |
| `configs/calibration.json` | 第一轮标定两个参数的范围、权重与步长 | 否 |
| `configs/calibration_extended.json` | 可选的五参数扩展标定配置 | 否 |
| `data/experiment_m20.csv` | −20 ℃加载输入与实验电压、温度 | 否 |
| `data/experiment_m25.csv` | −25 ℃独立验证数据 | 否 |
| `data/attachment1.xlsx` | 原附件1，原样保留作参数溯源 | 否 |
| `data/attachment2.xlsx` | 原附件2，原样保留作实验溯源 | 否 |
| `requirements.txt` | Python 库版本 | 首次运行需安装这些库 |
| `.vscode/launch.json` | VS Code 的 F5 运行配置 | 否 |

你需要安装 Python 和 VS Code。建议用 Python 3.12 或 3.13，并在 VS Code 安装 Microsoft 发布的 Python 扩展。代码运行不需要 Excel、MATLAB、COMSOL、API 密钥或本项目外的旧代码。

## 三 在 VS Code 中第一次打开

1. 解压整个 ZIP，保留目录结构，例如得到 `D:\work\pemfc_uncalibrated_vscode`。不要在压缩包里直接运行。
2. 打开 VS Code，点击“文件 → 打开文件夹”，选中包含 `simulate.py`、`README.md` 的这一层文件夹。
3. 点击“终端 → 新建终端”，选择 PowerShell。下面所有命令都在这个终端中执行。
4. 输入：

```powershell
Get-Location
Get-ChildItem
python --version
```

列表里应看到 `simulate.py`、`calibrate.py`、`configs`、`data`。如果没有，说明终端不在项目根目录。若 `python` 未找到，安装 Python 并重新打开终端，或使用你已经安装的 Python 可执行文件完整路径。

## 四 创建环境并安装依赖

在项目根目录逐行运行：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -c "import numpy, scipy, matplotlib; print(numpy.__version__, scipy.__version__, matplotlib.__version__)"
```

这里直接使用虚拟环境中的 Python，不需要执行 `Activate.ps1`，因此也不需要为此修改 PowerShell 执行策略。

在 VS Code 按 `Ctrl+Shift+P`，搜索 **Python: Select Interpreter**，选择项目中的 `.venv\Scripts\python.exe`。如果没有出现在列表中，选“Enter interpreter path”并找到该文件。终端命令已明确指定解释器，F5 调试则使用这里选择的解释器。

依赖固定为 NumPy 2.3.5、SciPy 1.16.3、Matplotlib 3.10.8。换版本后数值终止过程可能略有差异；先用这组版本复现。

## 五 先运行未标定模型

### 第一步 检查基准参数

打开 `configs/baseline.json`，应看到：

```json
{
  "j0_ref_A_m2": 0.01,
  "k_abs_l_s_inv": 0.5,
  "k_fr_K_inv_s_inv": 0.005,
  "delta_T_mem_K": 20.0,
  "heat_capacity_scale": 1.0,
  "alpha_effective": 0.5,
  "membrane_diffusivity_scale": 1.0
}
```

上面只展示文件中的 `parameters` 对象，真实文件外层还有状态说明。不要删除该外层结构。扩散与热容乘数均为 1，表示不加标定修正；交换电流密度 0.01 A/m² 是原参考模型的初始值。

### 第二步 跑完整 −20 ℃工况

```powershell
.\.venv\Scripts\python.exe simulate.py --case m20
```

终端开头应显示 `Parameter status: uncalibrated`，随后打印七个参数。结束后查看：

```text
outputs/baseline_m20/comparison.png
outputs/baseline_m20/predictions.csv
outputs/baseline_m20/metrics.json
outputs/baseline_m20/states.npz
```

- `comparison.png`：电压、温度、膜含水量和冰量曲线。
- `predictions.csv`：原观测与模型逐点结果，可用 Excel 或 VS Code 打开。
- `metrics.json`：RMSE、MAE、物理检查和总水量守恒残差。
- `states.npz`：全部控制体状态，供进一步画空间分布图。

基准曲线与实验不吻合并不等于程序运行失败。只有在参数未经标定时，才有必要观察这些偏差并决定校正什么。

### 第三步 跑未标定的 −25 ℃工况

```powershell
.\.venv\Scripts\python.exe simulate.py --case m25
```

输出位于 `outputs/baseline_m25`。本命令依然使用基准参数，不是此前提供的已标定对比图。

### 可选 从原始 Excel 重新生成 CSV

CSV 已经准备好了，普通运行不需要这一步。若你要核对原表或替换原始实验数据，可运行：

```powershell
.\.venv\Scripts\python.exe prepare_data.py
```

这会覆盖 `data/experiment_m20.csv` 与 `data/experiment_m25.csv`，但不修改两个 XLSX。程序只用 Python 标准库读取 Excel 文件结构，不要求安装 openpyxl。

## 六 亲手进行参数标定

### 第一步 明确哪些是输入 哪些是拟合目标

加载输入为实验表 E 列电流密度。C 列电压、D 列温度是拟合目标。温度方程只以 D 列首点设初始温度，后续温度由模型算出；不是把实测温度曲线直接强加给模型。

**原附件的 I 与 j 不满足 25 cm² 面积换算。**默认采用电流密度列，`current_A` 只保留作原始记录。若后续确认应采用电流列，你需要明确调整整个标定和验证流程，而不是只换图例。当前标定入口固定采用电流密度口径。

### 第二步 先只标定两个参数

打开 `configs/calibration.json`。默认的 `active` 为：

```json
"active": ["j0_ref_A_m2", "k_abs_l_s_inv"]
```

只让参考交换电流密度与液水吸脱水速率变化，其他参数固定为基准值。这样先观察模型对少量参数的响应，不把所有误差都塞进大量自由参数。

该文件还定义了：

- `lower`、`upper`：允许搜索的物理参数上下限。
- `transform: "log10"`：优化时用参数的十进制对数，保存的参数文件仍是正常物理数值。
- `step`：在优化坐标中的绝对有限差分步长。
- `voltage_scale_V: 0.02` 与 `temperature_scale_K: 0.2`：残差归一化尺度，不是已测得的仪器标准差。
- `max_nfev`：优化器允许的主残差评估次数，不等于总前向模型调用次数；数值 Jacobian 还需要额外调用。

### 第三步 执行标定

```powershell
.\.venv\Scripts\python.exe calibrate.py
```

程序每次真正运行前向模型都会打印：

```text
Forward run ...: J=..., best=..., elapsed=...s
```

J 是加权残差平方和。不同变量的原始单位不能直接相加，因此先除以 0.02 V 与 0.2 K。候选违反物理阈值时加入罚项；求解失败会记录原因。标定通常比单次模型运行慢很多，需要反复积分，可能耗时数分钟或更久，取决于机器与参数。

这一步不会覆盖 `configs/baseline.json`，也不会自动读取你上次生成的校正值作为初值。输出包括：

| 输出文件 | 怎么看 |
|---|---|
| `outputs/calibration_m20/fitted_parameters.json` | 优化器最终候选参数、终止原因、一阶最优性指标 |
| `outputs/calibration_m20/best_candidate.json` | 前向评估中最低目标值候选；可能含有限差分扰动点 |
| `outputs/calibration_m20/history.csv` | 每次前向求解的参数、目标值和错误信息 |
| `outputs/calibration_m20/comparison.png` | 最终候选的曲线对比 |
| `outputs/calibration_m20/metrics.json` | 最终候选的真实单位误差和物理检查 |
| `outputs/calibration_m20/initial_parameters.json` | 本次实际使用的初值快照 |
| `outputs/calibration_m20/jacobian.npz` | 局部残差灵敏度矩阵 |

如果你按 `Ctrl+C` 中止，可保留此前的 `best_candidate.json` 和历史；这不是优化完成，不能说已经收敛。

为避免旧结果与新结果混淆，标定目录已有历史或参数文件时，程序会拒绝覆盖。重跑时换一个输出目录，例如 `--output outputs/calibration_m20_run2`。模拟程序默认会覆盖它自己的同名输出，需保留多个对比方案时也请指定不同目录。

### 第四步 判断是否值得接受

依次检查：

1. `fitted_parameters.json` 的 `success` 和 `message`。达到迭代次数上限不代表成功；`xtol` 只说明步长小，不证明全局最优。
2. `metrics.json` 的五个 `physical_checks` 是否为 true，以及水量守恒残差是否足够小。
3. 比较标定前后的电压 RMSE、温度 RMSE 和残差趋势。不能只因温度拟合好就忽略电压系统偏差。
4. 参数是否贴近上下界。如果贴边，应核对单位、数据、模型结构或参数范围依据，不要只为减小误差无限放宽。
5. 不同初值是否得到相近的目标函数与参数；不同参数组合能拟合相同曲线时，参数可能不可辨识。

温度 RMSE 用 ℃ 或 K 的差值相同。温度 MAPE 这里按 ℃观测计算，与温标原点有关，接近 0 ℃时不宜作为主要指标。

### 第五步 必要时才扩展到五参数

如果两个参数仍不能解释电压变化，可执行明确的扩展标定：

```powershell
.\.venv\Scripts\python.exe calibrate.py --config configs/calibration_extended.json --output outputs/calibration_extended_m20
```

增加的三个量是热容乘数、有效电荷传递系数和膜水扩散乘数。这一步允许偏离 α=0.5、乘数=1 的基准假设，属于明确扩展，不能再称这些量未经修正。冻结速率与膜冻结宽度仍不参与自动标定。

扩展标定依然从未标定基准开始。若你想明确以前一轮两参数结果作为新初值，需要主动指定：

```powershell
.\.venv\Scripts\python.exe calibrate.py --initial outputs/calibration_m20/fitted_parameters.json --config configs/calibration_extended.json --output outputs/calibration_extended_from_stage1
```

不建议在只有电压、温度的短时间数据上，同时自由拟合所有相变系数、初始含水量、导电率与热物性。

### 第六步 固定新参数 验证 −25 ℃

使用两参数标定的结果：

```powershell
.\.venv\Scripts\python.exe simulate.py --case m25 --params outputs/calibration_m20/fitted_parameters.json --output outputs/validation_m25
```

使用扩展结果时，把 `--params` 换成对应的文件路径。**验证时只运行 simulate.py，不运行 calibrate.py。**否则 −25 ℃就变成训练数据，不能再作为独立验证。

### 第七步 检查网格误差

保持参数不变，将每层网格数加倍：

```powershell
.\.venv\Scripts\python.exe simulate.py --case m20 --params outputs/calibration_m20/fitted_parameters.json --refine 2 --output outputs/grid_check_m20
```

比较其电压、温度与原网格结果。若变化明显，需要先提高空间精度，再重新标定，而不是让参数补偿网格误差。

## 七 如何手动试一个参数

先复制基准配置，不直接改基准：

```powershell
Copy-Item configs/baseline.json configs/manual_trial.json
```

用 VS Code 打开 `configs/manual_trial.json`，例如仅把 `j0_ref_A_m2` 从 0.01 改为 0.02，保存后运行：

```powershell
.\.venv\Scripts\python.exe simulate.py --params configs/manual_trial.json --output outputs/manual_trial
```

这是试算，不是自动标定。逐一改参数才能看清响应。JSON 不能写 `//` 注释，末尾不能多逗号。文件中的 `status` 可改为 `manual_trial`，避免图上仍显示 uncalibrated。

## 八 F5 和常见问题

- F5：左侧“运行和调试”中有三个配置：运行未标定 −20 ℃、用 −20 ℃标定两个参数、用新参数验证 −25 ℃。第三项必须先完成第二项。选择正确的 `.venv` 解释器后再运行。
- `ModuleNotFoundError`：通常是 VS Code 用错 Python，或依赖没有安装到 `.venv`。用第四节的完整解释器路径安装和运行。
- 找不到 `fitted_parameters.json`：先运行标定并等待正常结束。只运行基准模拟不会生成拟合参数。
- `Output directory already contains a calibration run`：使用新的 `--output` 路径，例如 `outputs/calibration_m20_run2`，然后验证时引用这个新目录中的参数文件。
- 修改参数后结果没变：确认保存了 JSON，并在 `--params` 中指定该文件。默认始终读 `configs/baseline.json`。
- 标定慢：先用 `--max-nfev 2 --end-time 2 --output outputs/smoke_fit` 测试操作链路。这只拟合前 2 秒并很快停止，**不能作为正式标定结果**。
- 出现物理警告：查看 metrics；不要将已耗尽反应物或已堵满孔隙后的正则化计算曲线解释为真实可持续运行。
- matplotlib 没弹出窗口：程序采用文件输出方式，直接打开 `comparison.png`。
- 想换自己的数据：CSV 列名见 [数据说明](data/README.md)。自定义条件超过 m20/m25 时还需要扩展环境温度配置，不能只修改文件名。

## 九 校正算法到底在做什么

模型首先给定参数 θ，解一维方程得到 V(t;θ)、T(t;θ)，再计算：

```text
J(θ) = Σ[(V模型 − V实验)/0.02]^2
     + Σ[(T模型 − T实验)/0.2]^2
     + 物理阈值罚项
```

`scipy.optimize.least_squares(method="trf")` 使用有界信赖域反射算法更新 θ，前向有限差分计算 Jacobian，内部每次都重新求解 BDF 瞬态模型。代码没有把实验电压直接代入热源来伪造温升吻合。数值初值会影响局部优化结果，因此应检查多初值和独立工况。

官方操作与算法资料：[Python 虚拟环境](https://docs.python.org/3/library/venv.html)、[VS Code Python 环境](https://code.visualstudio.com/docs/python/environments)、[SciPy least_squares](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.least_squares.html)。
