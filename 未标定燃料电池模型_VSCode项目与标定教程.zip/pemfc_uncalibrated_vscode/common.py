"""Shared file handling, parameter transformations and output generation."""
from pathlib import Path
import json
import numpy as np
from model import Model,MW,F

ROOT=Path(__file__).resolve().parent
LOG_NAMES={'j0_ref_A_m2','k_abs_l_s_inv','k_fr_K_inv_s_inv','delta_T_mem_K','membrane_diffusivity_scale'}

def path(value):
    p=Path(value)
    return p if p.is_absolute() else ROOT/p

def read_json(filename):
    return json.loads(path(filename).read_text(encoding='utf-8-sig'))

def parameters(filename):
    obj=read_json(filename)
    p=obj['parameters']
    for k in Model.names:
        if k not in p or not np.isfinite(p[k]) or p[k]<=0:
            raise ValueError(f'Missing or non-positive parameter: {k}')
    return obj

def vector(p):
    return np.array([np.log10(p[k]) if k in LOG_NAMES else p[k] for k in Model.names])

def observations(case,filename=None,end_time=None):
    name=path(filename or f'data/experiment_{case}.csv')
    a=np.genfromtxt(name,delimiter=',',names=True,encoding='utf-8-sig')
    columns=['time_s','current_A','voltage_V','temperature_C','current_density_A_cm2']
    if a.dtype.names is None or any(k not in a.dtype.names for k in columns):
        raise ValueError(f'CSV must contain: {columns}')
    d=np.column_stack([np.atleast_1d(a[k]) for k in columns])
    if end_time is not None: d=d[d[:,0]<=end_time]
    if len(d)<2 or not np.isfinite(d).all() or np.any(np.diff(d[:,0])<=0):
        raise ValueError('Need at least two finite observations with strictly increasing time.')
    if np.any(d[:,4]<0): raise ValueError('Negative current density is outside this model.')
    return d

def make_model(d,case,gas_mode='transient',refine=1,current='density'):
    return Model(d,refine=refine,current=current,ambient_K={'m20':253.15,'m25':248.15}[case],gas_mode=gas_mode)

def metric(pred,exp):
    e=pred-exp; good=np.abs(exp)>1e-12; variance=np.sum((exp-exp.mean())**2)
    return {'RMSE':float(np.sqrt(np.mean(e**2))),'MAE':float(np.mean(abs(e))),
            'max_absolute_error':float(max(abs(e))),
            'MAPE_percent':float(np.mean(abs(e[good]/exp[good]))*100) if good.any() else None,
            'R2':float(1-np.sum(e**2)/variance) if variance>0 else None}

def physical_status(o):
    # Reporting checks do not silently alter the integrated state.
    return {'pore_capacity_ok':bool(np.max(o['pore_fill_max'])<1),
            'reactants_available':bool(np.min(o['gas_ratio_min'])>0),
            'ionomer_not_dry':bool(np.min(o['lambda_min'])>.326/.5139),
            'phase_nonnegative_with_tolerance':bool(np.min(o['phase_min'])>=-1e-6),
            'voltage_positive':bool(np.min(o['V'])>0)}

def save_results(directory,model,p,o,sol,label):
    dest=path(directory)
    if dest==ROOT or dest==ROOT/'configs' or ROOT/'configs' in dest.parents:
        raise ValueError('Outputs must not overwrite project/config directories.')
    dest.mkdir(parents=True,exist_ok=True)
    d=model.d; keys=list(o)
    values=np.column_stack([d]+[o[k] for k in keys])
    np.savetxt(dest/'predictions.csv',values,delimiter=',',
        header=','.join(['time_s','current_A','observed_V','observed_T_C','input_j_A_cm2']+['model_'+k for k in keys]),
        comments='',encoding='utf-8-sig')
    produced=np.r_[0,np.cumsum(np.diff(d[:,0])*(model.j[:-1]+model.j[1:])/2)]*MW/(2*F)
    balance=o['water_kg_m2']-o['water_kg_m2'][0]+o['outflow_kg_m2']-produced
    stats={'label':label,'gas_mode':model.gas_mode,'ambient_K':model.ambient_K,
        'initial_temperature_C':float(d[0,3]),'current_input':model.current,'parameters':p,
        'voltage':metric(o['V'],d[:,2]),'temperature_C':metric(o['T_C'],d[:,3]),
        'physical_checks':physical_status(o),'water_balance_max_kg_m2':float(max(abs(balance))),
        'water_balance_fraction_of_production':float(max(abs(balance))/produced[-1]) if produced[-1]>0 else None,
        'lambda_mean_initial':float(o['lambda_mean'][0]),'lambda_mean_final':float(o['lambda_mean'][-1])}
    (dest/'metrics.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    np.savez_compressed(dest/'states.npz',time=sol.t,states=sol.y,layer=model.layer,dx=model.dx,
                        pore_nodes=model.p,ionomer_nodes=model.ion,state_offsets=model.cuts)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    # English figure labels make the exported project independent of Chinese fonts.
    fig,axs=plt.subplots(2,2,figsize=(11,7.5),layout='constrained')
    for ax,k,exp,ylabel in [(axs[0,0],'V',d[:,2],'Voltage (V)'),(axs[0,1],'T_C',d[:,3],'Temperature (deg C)')]:
        ax.plot(d[:,0],exp,'o',ms=3,label='Experiment'); ax.plot(d[:,0],o[k],lw=1.7,label='Model'); ax.set_ylabel(ylabel)
    axs[1,0].plot(d[:,0],o['lambda_mean'],label='Total membrane water')
    axs[1,0].plot(d[:,0],o['lambda_u_mean'],label='Unfrozen membrane water'); axs[1,0].set_ylabel('Water content (lambda)')
    axs[1,1].plot(d[:,0],o['ice_fraction_max'],label='Max pore-ice volume fraction')
    axs[1,1].plot(d[:,0],o['ice_saturation_max'],label='Max ice saturation'); axs[1,1].set_ylabel('Volume fraction / saturation')
    for ax in axs.flat: ax.set_xlabel('Time (s)'); ax.grid(alpha=.2); ax.legend(fontsize=9)
    fig.suptitle(label); fig.savefig(dest/'comparison.png',dpi=180); plt.close(fig)
    return stats
