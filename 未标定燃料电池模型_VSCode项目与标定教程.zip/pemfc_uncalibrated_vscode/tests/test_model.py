"""Small conservation/data checks; run with python -m unittest discover -s tests -v."""
import unittest
import numpy as np
from common import observations,parameters,vector,make_model
from model import MW,F,CW

class ModelChecks(unittest.TestCase):
    def setUp(self):
        self.d=observations('m20')
        self.p=parameters('configs/baseline.json')['parameters']
        self.z=vector(self.p)

    def test_baseline_is_uncalibrated(self):
        self.assertEqual(self.p['j0_ref_A_m2'],.01)
        self.assertEqual(self.p['alpha_effective'],.5)
        self.assertEqual(self.p['membrane_diffusivity_scale'],1)
        self.assertEqual(self.p['heat_capacity_scale'],1)

    def test_data(self):
        self.assertEqual(len(self.d),184)
        self.assertEqual(len(observations('m25')),184)
        self.assertTrue(np.all(np.diff(self.d[:,0])>0))

    def test_total_water_derivative(self):
        m=make_model(self.d,'m20'); y=m.initial(self.z)
        # Include nonzero pore phases to exercise phase exchanges and drainage.
        y[m.sl[0]]=1e-4; y[m.sl[1]]=.2; y[m.sl[2]]=.1
        dy=m.calc(0,y,self.z)
        pore=np.dot(dy[m.sl[0]]+dy[m.sl[1]]+dy[m.sl[2]],m.dx[m.p])
        ion=np.dot(m.omega[m.ion]*CW*(dy[m.sl[3]]+dy[m.sl[4]]),m.dx[m.ion])
        net=pore+ion+dy[m.sl[6]][0]-MW*m.j[0]/(2*F)
        self.assertLess(abs(net),1e-12)

    def test_initial_gas_stoichiometry(self):
        m=make_model(self.d,'m20'); y=m.initial(self.z); dy=m.calc(0,y,self.z)
        h=np.dot(dy[m.sl[7]],m.dx[m.p]); o=np.dot(dy[m.sl[8]],m.dx[m.p])
        # Initially uniform inlet concentrations imply zero boundary diffusive flux.
        self.assertAlmostEqual(h,-m.j[0]/(2*F),places=10)
        self.assertAlmostEqual(o,-m.j[0]/(4*F),places=10)

    def test_modes_and_ambient(self):
        m=make_model(self.d,'m20'); q=make_model(self.d,'m20','quasisteady')
        self.assertEqual(m.nstate-q.nstate,2*m.np)
        self.assertEqual(make_model(observations('m25'),'m25').ambient_K,248.15)

if __name__=='__main__': unittest.main()
