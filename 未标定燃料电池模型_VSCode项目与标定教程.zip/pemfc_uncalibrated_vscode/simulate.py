"""Run the uncalibrated model by default; fitted files require --params explicitly."""
import argparse,json
from common import parameters,vector,observations,make_model,save_results

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case',choices=['m20','m25'],default='m20')
    ap.add_argument('--params',default='configs/baseline.json')
    ap.add_argument('--data',help='Optional CSV with documented headers')
    ap.add_argument('--output')
    ap.add_argument('--gas-mode',choices=['transient','quasisteady'],default='transient')
    ap.add_argument('--current',choices=['density','current'],default='density',help='density: E column; current: I / 25 cm2')
    ap.add_argument('--refine',type=int,default=1)
    ap.add_argument('--end-time',type=float,help='Shorten run for a smoke test; not a full calibration')
    args=ap.parse_args()
    if args.refine<1: ap.error('--refine must be >= 1')
    config=parameters(args.params); p=config['parameters']
    print('Parameter status:',config.get('status','unspecified'))
    print(json.dumps(p,indent=2))
    d=observations(args.case,args.data,args.end_time)
    model=make_model(d,args.case,args.gas_mode,args.refine,args.current)
    o,sol=model.run(vector(p),rtol=2e-6,max_step=.1)
    dest=args.output or (f'outputs/baseline_{args.case}' if config.get('status')=='uncalibrated' else f'outputs/simulation_{args.case}')
    stats=save_results(dest,model,p,o,sol,f"{args.case}: {config.get('status','specified parameters')}")
    print(json.dumps(stats,ensure_ascii=False,indent=2))
    print('Output:',dest)
    if not all(stats['physical_checks'].values()):
        print('WARNING: physical limits exceeded; inspect metrics before interpreting curves.')

if __name__=='__main__': main()
