"""Recreate the included CSVs from original XLSX without Excel or openpyxl."""
from pathlib import Path
import csv
import json
import zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
HEADERS=['time_s','current_A','voltage_V','temperature_C','current_density_A_cm2']

def read_workbook(path):
    with zipfile.ZipFile(path) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        result={}
        for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',NS):
            target=rels[sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
            target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            rows=[]
            for r in ET.fromstring(z.read(target)).findall('.//s:row',NS):
                row={}
                for c in r:
                    col=''.join(ch for ch in c.get('r') if ch.isalpha())
                    v=c.find('s:v',NS)
                    value=v.text if v is not None else ''.join(c.itertext())
                    row[col]=strings[int(value)] if c.get('t')=='s' else value
                rows.append(row)
            result[sheet.get('name')]=rows
        return result

def main():
    book=read_workbook(ROOT/'data/attachment2.xlsx')
    for sheet,case in [('-20℃','m20'),('-25℃','m25')]:
        rows=[[float(r[c]) for c in 'ABCDE'] for r in book[sheet][2:]]
        with (ROOT/f'data/experiment_{case}.csv').open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(HEADERS); w.writerows(rows)
        print(f'{sheet}: {len(rows)} observations -> data/experiment_{case}.csv')

if __name__=='__main__': main()
