"""Calibrate from the uncalibrated JSON explicitly. No automatic warm start."""
import argparse,csv,hashlib,json,time
import numpy as np
from scipy.optimize import least_squares
from common import ROOT,path,read_json,parameters,vector,observations,make_model,save_results

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--initial',default='configs/baseline.json')
    ap.add_argument('--config',default='configs/calibration.json')
    ap.add_argument('--output',default='outputs/calibration_m20')
    ap.add_argument('--case',choices=['m20','m25'],default='m20')
    ap.add_argument('--gas-mode',choices=['transient','quasisteady'],default='transient')
    ap.add_argument('--max-nfev',type=int)
    ap.add_argument('--end-time',type=float,help='Use only an early segment for workflow testing')
    args=ap.parse_args()
    initial_path=path(args.initial); original=initial_path.read_bytes()
    base=parameters(args.initial)['parameters']; settings=read_json(args.config)
    active=settings['active']
    if not active or len(active)!=len(set(active)): raise ValueError('Active parameter list must be nonempty and unique.')
    if any(k not in base for k in active): raise ValueError('Unknown active parameter.')
    dest=path(args.output).resolve()
    if dest==ROOT or dest==ROOT/'configs' or ROOT/'configs' in dest.parents:
        raise ValueError('Choose an output directory separate from configs.')
    dest.mkdir(parents=True,exist_ok=True)
    if any((dest/name).exists() for name in ['history.csv','fitted_parameters.json','best_candidate.json']):
        raise ValueError('Output directory already contains a calibration run. Choose a new --output directory.')
    if initial_path.resolve()==dest/'fitted_parameters.json': raise ValueError('Never overwrite the input parameter file.')
    specs=[settings['bounds'][k] for k in active]
    if any(s['transform'] not in ['log10','linear'] for s in specs): raise ValueError('Use log10 or linear transforms.')
    def encode(value,s): return np.log10(value) if s['transform']=='log10' else value
    q0=np.array([encode(base[k],s) for k,s in zip(active,specs)])
    lb=np.array([encode(s['lower'],s) for s in specs]); ub=np.array([encode(s['upper'],s) for s in specs])
    if not np.isfinite(np.r_[lb,ub,q0]).all() or np.any(lb>=ub) or np.any(q0<lb) or np.any(q0>ub):
        raise ValueError('Initial parameters must lie inside valid finite bounds.')
    def decode(q):
        p=base.copy()
        for k,v,s in zip(active,q,specs): p[k]=float(10**v if s['transform']=='log10' else v)
        return p
    d=observations(args.case,end_time=args.end_time)
    model=make_model(d,args.case,args.gas_mode)
    counter=0; best_cost=float('inf'); start=time.monotonic(); cache={}
    vf=float(settings['voltage_scale_V']); tf=float(settings['temperature_scale_K'])
    if vf<=0 or tf<=0: raise ValueError('Residual scales must be positive.')
    def residual(q):
        nonlocal counter,best_cost
        key=np.asarray(q).tobytes()
        if key in cache: return cache[key].copy()
        counter+=1; p=decode(q); error=''
        try:
            o,_=model.run(vector(p),rtol=settings['rtol'],max_step=settings['max_step_s'])
            r=np.r_[(o['V']-d[:,2])/vf,(o['T_C']-d[:,3])/tf,
                    100*np.maximum(o['pore_fill_max']-.95,0),
                    100*np.maximum(.05-o['gas_ratio_min'],0),
                    100*np.maximum(.8-o['lambda_min'],0)]
            if not np.isfinite(r).all(): raise RuntimeError('Non-finite residual')
        except (RuntimeError,ValueError,FloatingPointError) as exc:
            r=np.full(len(d)*5,1e5); error=str(exc)
        score=float(np.dot(r,r))
        with (dest/'history.csv').open('a',newline='',encoding='utf-8') as f:
            csv.writer(f).writerow([counter,score,time.monotonic()-start]+[p[k] for k in active]+[error])
        if not error and score<best_cost:
            best_cost=score
            candidate={'status':'calibration_candidate','parameters':p,'objective_sum_squares':score,
                       'active_parameters':active,'case':args.case,'gas_mode':args.gas_mode}
            (dest/'best_candidate.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'Forward run {counter}: J={score:.6g}, best={best_cost:.6g}, elapsed={time.monotonic()-start:.1f}s',flush=True)
        if error: print('  Rejected candidate:',error,flush=True)
        cache[key]=r.copy()
        return r
    def jac(q):
        r=residual(q); cols=[]
        for i,s in enumerate(specs):
            h=float(s['step'])
            if h<=0: raise ValueError('Finite difference steps must be positive.')
            if q[i]+h>ub[i]: h=-h
            if q[i]+h<lb[i]: h=(ub[i]-lb[i])*.01
            qq=q.copy(); qq[i]+=h
            cols.append((residual(qq)-r)/h)
        return np.column_stack(cols)
    with (dest/'history.csv').open('w',newline='',encoding='utf-8') as f:
        csv.writer(f).writerow(['forward_run','objective_sum_squares','elapsed_s']+active+['error'])
    (dest/'initial_parameters.json').write_bytes(original)
    (dest/'calibration_settings.json').write_text(json.dumps(settings,indent=2),encoding='utf-8')
    result=least_squares(residual,q0,bounds=(lb,ub),jac=jac,method='trf',loss='linear',
                         max_nfev=args.max_nfev or settings['max_nfev'],ftol=settings['ftol'],
                         xtol=settings['xtol'],gtol=settings['gtol'],verbose=1)
    p=decode(result.x)
    o,sol=model.run(vector(p),rtol=2e-6,max_step=.1)
    output={'status':'calibrated_candidate','parameters':p,'case':args.case,'gas_mode':args.gas_mode,
            'active_parameters':active,'success':bool(result.success),'message':str(result.message),
            'nfev':int(result.nfev),'forward_runs':counter,'optimality':float(result.optimality),
            'objective_sum_squares':float(2*result.cost),'singular_values':np.linalg.svd(result.jac,compute_uv=False).tolist(),
            'parameter_coordinates':[s['transform'] for s in specs],
            'initial_sha256':hashlib.sha256(original).hexdigest(),'data_end_s':float(d[-1,0]),
            'note':'Local candidate only. success does not establish a unique/global optimum.'}
    (dest/'fitted_parameters.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    np.savez(dest/'jacobian.npz',jacobian=result.jac,active=np.array(active))
    save_results(dest,model,p,o,sol,f'{args.case}: user-run calibration candidate')
    assert initial_path.read_bytes()==original, 'Input parameter file was modified.'
    print('Finished. Initial file unchanged. Results:',dest)
    print('Stop condition:',result.message,'; optimality:',result.optimality)

if __name__=='__main__': main()
