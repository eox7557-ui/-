"""One-dimensional layered PEMFC cold-start equations; no fitted values loaded.

SI units. Pore vapor/liquid/ice and ionomer unfrozen/frozen water are separate
conserved inventories. Default gas_mode='transient' solves H2/O2 storage too;
'quasisteady' explicitly enables the earlier fast approximation.
Fixed material constants below come from the supplied attachment; kinetic
closure assumptions are documented in docs/PARAMETERS.md.
"""
import numpy as np
from scipy.integrate import solve_ivp
F=96485.; R=8.314; MW=.018; CW=2150.*MW; TM=273.15

class Model:
    # Parameters: log10 j0_ref, log10 liquid absorption rate, log10 freezing rate,
    #             log10 membrane freezing width, thermal capacity multiplier.
    names=['j0_ref_A_m2','k_abs_l_s_inv','k_fr_K_inv_s_inv','delta_T_mem_K','heat_capacity_scale','alpha_effective','membrane_diffusivity_scale']
    def __init__(self,d,refine=1,current='density',ambient_K=253.15,gas_mode='transient'):
        self.d=d; self.t=d[:,0]
        self.ambient_K=float(ambient_K)
        self.gas_mode=gas_mode
        if gas_mode not in ("transient","quasisteady"): raise ValueError("Invalid gas mode")
        self.j=d[:,4]*1e4 if current=='density' else d[:,1]/.0025
        self.current=current; self.refine=refine
        # Five material layers, optional refinement of every layer.
        count=np.array([2,2,4,2,2])*refine
        lengths=np.array([150e-6,3.4e-6,12e-6,11.3e-6,150e-6])
        self.layer=np.repeat(np.arange(5),count)
        self.dx=np.repeat(lengths/count,count); self.n=len(self.dx)
        self.p=np.where(self.layer!=2)[0]; self.ion=np.where(np.isin(self.layer,[1,2,3]))[0]
        self.np=len(self.p); self.ni=len(self.ion)
        self.ep=np.array([.8,.3916,0,.4207,.8])[self.layer]
        self.omega=np.array([0,.3,1,.3,0])[self.layer]
        self.K0=np.array([6.2e-12,6.2e-13,0,6.2e-13,6.2e-12])[self.layer]
        self.theta=np.deg2rad(np.array([110,100,0,100,110])[self.layer])
        self.side_a=self.layer[self.p]<2
        self.p_edges=np.where(np.diff(self.p)==1)[0]
        self.ion_edges=np.arange(self.ni-1)
        self.clion=np.where(self.layer[self.ion]!=2)[0]
        self.clp=np.array([int(np.where(self.p==self.ion[i])[0][0]) for i in self.clion])
        # Uniform reaction currents in each catalyst layer.
        self.im=np.zeros(self.n); self.im[self.layer==2]=1.
        for lay,reverse in [(1,False),(3,True)]:
            ix=np.where(self.layer==lay)[0]; z=(np.arange(len(ix))+.5)/len(ix)
            self.im[ix]=1-z if reverse else z
        # Heat domain includes two 2 mm bipolar plates, each split twice.
        nb=2*refine; self.nb=nb
        self.hdx=np.r_[np.full(nb,.002/nb),self.dx,np.full(nb,.002/nb)]
        self.nh=len(self.hdx); self.hmea=np.arange(nb,nb+self.n)
        self.kt=np.r_[np.full(nb,95.),np.array([.3,.27,.24,.27,.3])[self.layer],np.full(nb,95.)]
        self.ct=np.r_[np.full(nb,1980*766),np.array([185*545,970*240,2150*1050,970*240,185*545])[self.layer],np.full(nb,1980*766)]
        self.hG=1/(self.hdx[:-1]/(2*self.kt[:-1])+self.hdx[1:]/(2*self.kt[1:]))
        self.hC=self.ct*self.hdx
        self.sizes=[self.np]*3+[self.ni]*2+[self.nh,1]
        if self.gas_mode=="transient": self.sizes += [self.np,self.np]
        cuts=np.cumsum([0]+self.sizes); self.sl=[slice(cuts[k],cuts[k+1]) for k in range(len(self.sizes))]
        self.cuts=cuts; self.nstate=cuts[-1]
        # Initial pore water is zero. Membrane total lambda=3 per attachment.
        self.mask_ccl=self.layer[self.p]==3

    @staticmethod
    def unpack_params(z):
        return np.r_[10**np.asarray(z[:4]),z[4],z[5] if len(z)>5 else .5,10**z[6] if len(z)>6 else 1.]

    def initial(self,z):
        pars=self.unpack_params(z); delta=pars[3]
        y=np.zeros(self.nstate); t0=self.d[0,3]+273.15
        lf=(3-2)*(1-np.exp(-max(TM-t0,0)/delta))
        y[self.sl[3]]=3-lf; y[self.sl[4]]=lf; y[self.sl[5]]=t0
        if self.gas_mode=='transient':
            yo=(.233/.032)/(.233/.032+.767/.028)
            y[self.sl[7]]=self.ep[self.p]*101325/(R*t0)*self.side_a
            y[self.sl[8]]=self.ep[self.p]*yo*101325/(R*t0)*(~self.side_a)
        return y

    def calc(self,t,y,z,details=False):
        j0,ka,kfr,delta,cscale,alpha,dscale=self.unpack_params(z)
        j=float(np.interp(t,self.t,self.j)); P=self.p; I=self.ion
        mv0,ml0,mi0,lu0,lf0,TH0,out0=[y[s] for s in self.sl[:7]]
        # Positive values in constitutive laws; conserved states are never clipped after stepping.
        mv=np.maximum(mv0,0); ml=np.maximum(ml0,0); mi=np.maximum(mi0,0)
        lu=np.maximum(lu0,0); lf=np.maximum(lf0,0); TH=TH0; T=TH[self.hmea]; TP=T[P]; TI=T[I]
        ep=self.ep[P]; sl=ml/(990*ep); si=mi/(920*ep)
        eg=ep*np.maximum(1-sl-si,1e-9)
        cv=mv/(MW*eg)
        tc=TP-TM
        psatl=611.21*np.exp((18.678-tc/234.5)*tc/(257.14+tc))
        psati=611.15*np.exp((23.036-tc/333.7)*tc/(279.82+tc))
        csatl=psatl/(R*TP); csati=psati/(R*TP)
        Dref=np.where(self.side_a,8.69e-5,2.48e-5)
        Dv=Dref*(TP/298.15)**1.75*eg**1.5
        dmv=np.zeros(self.np); dml=np.zeros(self.np); dmi=np.zeros(self.np)
        # Shared vapor interface fluxes.
        e=self.p_edges; a=e; b=e+1
        G=MW/(self.dx[P[a]]/(2*Dv[a])+self.dx[P[b]]/(2*Dv[b]))
        flux=G*(cv[a]-cv[b]); np.add.at(dmv,a,-flux/self.dx[P[a]]); np.add.at(dmv,b,flux/self.dx[P[b]])
        vapout=0.
        for q in [0,self.np-1]:
            f=2*MW*Dv[q]*cv[q]/self.dx[P[q]]; dmv[q]-=f/self.dx[P[q]]; vapout+=f
        # Darcy capillary flow, monotone hydrophobic drainage curve, no entry barrier.
        Se=sl/np.maximum(1-si,1e-8)
        pc=.075*np.abs(np.cos(self.theta[P]))*np.sqrt(ep/self.K0[P])*(1.417*Se-2.120*Se**2+1.263*Se**3)
        Kl=self.K0[P]*np.maximum(1-si,0)**3*sl**3
        mu=.00179*np.exp(.025*(TM-TP))
        mob=990*Kl/mu
        # Donor relative mobility lets a wet cell invade an initially dry neighbor.
        # Harmonic averaging full liquid mobility would artificially seal every dry face.
        abs_mob=990*self.K0[P]*np.maximum(1-si,0)**3/mu
        GG=1/(self.dx[P[a]]/(2*np.maximum(abs_mob[a],1e-35))+self.dx[P[b]]/(2*np.maximum(abs_mob[b],1e-35)))
        GG*=np.where(pc[a]>=pc[b],sl[a],sl[b])**3
        fliq=GG*(pc[a]-pc[b]); np.add.at(dml,a,-fliq/self.dx[P[a]]); np.add.at(dml,b,fliq/self.dx[P[b]])
        liqout=0.
        for q in [0,self.np-1]:
            f=max(2*mob[q]*pc[q]/self.dx[P[q]],0); dml[q]-=f/self.dx[P[q]]; liqout+=f
        # Vapor condensation/evaporation; smooth wetting area vanishes without liquid.
        rvl=MW*eg*(np.maximum(cv-csatl,0)-sl/(sl+1e-3)*np.maximum(csatl-cv,0))
        rvi=MW*eg*1e-4*(np.maximum(cv-csati,0)*(TP<TM)-si/(si+1e-3)*np.maximum(csati-cv,0))
        rli=kfr*ml*np.maximum(TM-TP,0)-.2*mi*np.maximum(TP-TM,0)
        av=np.zeros(self.np); al=np.zeros(self.np)
        ip=self.clion; pp=self.clp
        aw=np.clip(cv[pp]/csatl[pp],0,1)
        leq=.043+17.81*aw-39.85*aw**2+36*aw**3
        av[pp]=.001*self.omega[P[pp]]*CW*(leq-lu[ip])
        # Finite liquid-ionomer exchange; desorption uses same liquid contact factor.
        al[pp]=ka*self.omega[P[pp]]*CW*(sl[pp]/(sl[pp]+1e-3))*(14-lu[ip])
        # Adsorbing vapor cannot consume water when cv=0; regularized availability.
        av=np.where(av>0,av*cv/(cv+1e-5),av)
        sw=np.zeros(self.np); sw[self.mask_ccl]=MW*j/(2*F*11.3e-6)
        dmv+=-rvl-rvi-av; dml+=sw+rvl-rli-al; dmi+=rli+rvi
        # Membrane and CL ionomer network. Unfrozen diffusion + electroosmotic drag.
        om=self.omega[I]; Dlam=1e-10*np.exp(2416*(1/303.15-1/TI))*(2.563-.33*lu+.0264*lu**2-.000671*lu**3)
        coeff=CW*om**1.5*np.maximum(Dlam,1e-14)*dscale
        Gi=1/(self.dx[I[:-1]]/(2*coeff[:-1])+self.dx[I[1:]]/(2*coeff[1:]))
        # Upwind drag in +x direction uses donor lambda and exact face proton current.
        imface=.5*(self.im[I[:-1]]+self.im[I[1:]])
        for q in range(len(imface)):
            if self.layer[I[q]]!=self.layer[I[q+1]]: imface[q]=1.
        fu=Gi*(lu[:-1]-lu[1:])+MW*(2.5*lu[:-1]/22)*j*imface/F
        dmu=np.zeros(self.ni); dmu[:-1]-=fu/self.dx[I[:-1]]; dmu[1:]+=fu/self.dx[I[1:]]
        dmu[ip]+=av[pp]+al[pp]
        total=lu+lf; target=np.maximum(total-2,0)*(1-np.exp(-np.maximum(TM-TI,0)/delta))
        ruf=om*CW*(target-lf) # fixed relaxation time 1 s
        dlu=(dmu-ruf)/(om*CW); dlf=ruf/(om*CW)
        # Reactant equations retain d(epsilon_g*c)/dt in the default mode.
        gas_derivatives=[]
        yO=(.233/.032)/(.233/.032+.767/.028)
        if self.gas_mode=='transient':
            gasrat={}; gasmin=1.
            for field,side,cl,ne,D0,yin in [(7,'a',1,2,1.10e-4,1.),(8,'c',3,4,2.20e-5,yO)]:
                inventory=y[self.sl[field]]
                concentration=np.maximum(inventory,0)/eg
                dg=np.zeros(self.np)
                active=self.side_a if side=='a' else ~self.side_a
                a=self.p_edges; b=a+1
                keep=active[a]&active[b]; a=a[keep]; b=b[keep]
                DD=D0*(TP/298.15)**1.75*eg**1.5
                conductance=1/(self.dx[P[a]]/(2*DD[a])+self.dx[P[b]]/(2*DD[b]))
                fg=conductance*(concentration[a]-concentration[b])
                np.add.at(dg,a,-fg/self.dx[P[a]])
                np.add.at(dg,b,fg/self.dx[P[b]])
                boundary=0 if side=='a' else self.np-1
                inlet=yin*101325/(R*TP[boundary])
                dg[boundary]+=2*DD[boundary]*(inlet-concentration[boundary])/self.dx[P[boundary]]**2
                reaction=self.layer[P]==cl
                thickness=3.4e-6 if side=='a' else 11.3e-6
                dg[reaction]-=j/(ne*F*thickness)
                gasrat[side]=np.average(concentration[reaction],weights=self.dx[P[reaction]])/inlet
                gasmin=min(gasmin,gasrat[side])
                gas_derivatives.append(dg)
        else:
            yO=(.233/.032)/(.233/.032+.767/.028)
            gasrat={}; gasmin=1.
            for side,laycl,ne,D0,yin in [('a',1,2,1.10e-4,1.),('c',3,4,2.20e-5,yO)]:
                ids=np.where(self.layer[P]<2)[0] if side=='a' else np.where(self.layer[P]>2)[0][::-1]
                DD=D0*(TP[ids]/298.15)**1.75*eg[ids]**1.5
                cc=yin*101325/(R*TP[ids[0]]); cin=cc; ccl=[]
                for ii,q in enumerate(ids):
                    lay=self.layer[P[q]]
                    if lay==laycl:
                        ncl=np.count_nonzero(self.layer==laycl)
                        rank=len(ccl); fmid=j/(ne*F)*(1-(rank+.5)/ncl)
                    else: fmid=j/(ne*F)
                    drop=fmid*self.dx[P[q]]/DD[ii]
                    if lay==laycl: ccl.append(cc-.5*drop)
                    cc-=drop
                ratio=np.mean(ccl)/cin; gasrat[side]=ratio; gasmin=min(gasmin,ratio)
        Tr=float(np.average(T[self.layer==3],weights=self.dx[self.layer==3]))
        er=1.229-8.5e-4*(Tr-298.15)+R*Tr/(2*F)*np.log(np.sqrt(yO))
        fA=np.average(np.maximum(1-si[self.mask_ccl],1e-9)**3.5,weights=self.dx[P[self.mask_ccl]])
        jzero=j0*np.exp(-67000/R*(1/Tr-1/298.15))*fA
        act=R*Tr/(alpha*F)*np.arcsinh(j/(2*max(jzero,1e-20)))
        kion=np.maximum(.5139*lu-.326,1e-9)*np.exp(1268*(1/303.15-1/TI))*om**1.5
        ohm=j*np.sum(self.im[I]**2*self.dx[I]/kion)+j*1e-6
        con=-R*Tr/(2*F)*np.log(max(gasrat['a'],1e-12))-R*Tr/(4*F)*np.log(max(gasrat['c'],1e-12))
        V=er-act-ohm-con
        # All electrochemical heat assigned to cCL; total integral is j(1.48-V).
        qheat=np.zeros(self.nh); cclidx=np.where(self.layer==3)[0]
        qheat[self.hmea[cclidx]]=j*(1.48-V)/11.3e-6
        qheat[self.hmea[P]]+=2.5e6*rvl+(2.5e6+333600)*rvi+333600*rli
        qheat[self.hmea[I]]+=333600*ruf
        qareal=qheat*self.hdx
        hf=self.hG*(TH[:-1]-TH[1:]); qareal[:-1]-=hf; qareal[1:]+=hf
        qareal[0]-=40*(TH[0]-self.ambient_K); qareal[-1]-=40*(TH[-1]-self.ambient_K)
        dTH=qareal/(self.hC*cscale)
        dy=np.concatenate([dmv,dml,dmi,dlu,dlf,dTH,[vapout+liqout]])
        if gas_derivatives: dy=np.r_[dy,*gas_derivatives]
        if details:
            water=np.dot(mv0+ml0+mi0,self.dx[P])+np.dot(om*CW*(lu0+lf0),self.dx[I])
            return {'V':V,'T_C':np.average(T,weights=self.dx)-273.15,
                    'lambda_mean':np.average((lu0+lf0)[self.layer[I]==2],weights=self.dx[I[self.layer[I]==2]]),
                    'lambda_u_mean':np.average(lu0[self.layer[I]==2],weights=self.dx[I[self.layer[I]==2]]),
                    'lambda_min':float(np.min(lu0)), 'ice_fraction_max':float(np.max(ep*si)),
                    'ice_saturation_max':float(np.max(si)), 'pore_fill_max':float(np.max(si+sl)),
                    'gas_ratio_min':gasmin,'water_kg_m2':water,'outflow_kg_m2':out0[0],
                    'water_rate_error':float(np.dot(dmv+dml+dmi,self.dx[P])+np.dot(om*CW*(dlu+dlf),self.dx[I])+vapout+liqout-MW*j/(2*F)),
                    'heat_min_C':float(np.min(TH)-273.15),'heat_max_C':float(np.max(TH)-273.15),
                    'phase_min':float(min(np.min(mv0),np.min(ml0),np.min(mi0))),
                    'act':act,'ohm':ohm,'con':con}
        return dy

    def run(self,z,rtol=2e-5,max_step=.25):
        y0=self.initial(z)
        sol=solve_ivp(lambda t,y:self.calc(t,y,z),(self.t[0],self.t[-1]),y0,
                      method='BDF',t_eval=self.t,rtol=rtol,atol=1e-8,max_step=max_step)
        if not sol.success or sol.y.shape[1]!=len(self.t): raise RuntimeError(sol.message)
        obs=[self.calc(t,y,z,True) for t,y in zip(sol.t,sol.y.T)]
        return {k:np.array([o[k] for o in obs]) for k in obs[0]},sol
